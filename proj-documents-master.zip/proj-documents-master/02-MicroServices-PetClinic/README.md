## Pet Clinic Setup Document 

### MariaDB Setup

Pet Clinic Application needs DB and we are choosing MariaDB for the same.

```
# yum install mariadb-server -y 
# systemctl enable mariadb 
# systemctl start mariadb 
# wget https://studentapi-cit.s3-us-west-2.amazonaws.com/pet-schema.sql -O /tmp/pet-schema.sql 
# mysql </tmp/pet-schema.sql 
```


To run the application as normal user we need to add a user , Also need Java to run the applications and hence we need that as well.

```
# yum install java -y 
# useradd petclinic 
# su - petclinic 
``` 

Following commands from now on should run as `petclinic` user.

```
$ curl https://studentapi-cit.s3-us-west-2.amazonaws.com/sprint-petclinic.tar.gz | tar -xz
```

Start the jar files.

```
$ cat startup.sh 
nohup java -jar spring-petclinic-config-server.jar &>config.log &
sleep 30
nohup java -jar spring-petclinic-discovery-server.jar &>discovery.log & 
sleep 30 
nohup java -jar spring-petclinic-api-gateway.jar &>api.log & 
nohup java -jar spring-petclinic-vets-service.jar &>vets.log & 
nohup java -jar spring-petclinic-visits-service.jar &>visists.log & 
nohup java -jar spring-petclinic-customers-service.jar &>customer.log & 
```